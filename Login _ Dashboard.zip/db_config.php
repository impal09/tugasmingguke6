<?php

	$host = 'localhost';
	$dbname = 'sp3opart1';
	$username = 'root';
	$password = '';
